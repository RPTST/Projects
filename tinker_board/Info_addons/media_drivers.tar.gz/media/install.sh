#!/bin/bash
sudo cp -r lib /
sudo /sbin/depmod -a 4.4.71+
