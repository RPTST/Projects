#!/bin/bash
#Get root access
sudo mkdir testing
sudo rm -R testing
clear
echo "This will install libraries needed for Netflix, Amazon Prime, and Hulu video playback on the Asus Tinkerboard"
echo ""
echo "These libraries were tested on"
echo "Debian Stretch 9.0 (2.0.4)"
echo "Chromium 62.0.3202.89 (Developer Build)"
echo ""
echo "Press [Enter] to continue"
read var
echo ""
echo "Copying shortcut..."
sudo cp chromium-user.desktop /usr/share/applications
echo "Copying libraries..."
sudo cp lib* /usr/lib/chromium
sudo cp -R pepper /usr/lib/chromium
echo "Installing chromium-widevine..."
sudo dpkg -i chromium-widevine_63.0.3239.84-1_deb9u1_armhf.deb
sudo apt-get install -y -f
echo "Done"
echo ""
echo "You can either use the shortcut that was installed in your menu in Internet, or launch with the command line below"
echo "chromium --user-agent=\"Mozilla/5.0 (X11; CrOS armv7l 6946.63.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2357.130 Safari/537.36\""
echo ""
echo "If you have any questions or need help, refer to the README or go to"
echo "https://tinkerboarding.co.uk/forum/thread-329.html"
echo ""